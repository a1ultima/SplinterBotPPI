

cd ./scripts

python ./uniprotPDB_to_ipfamPPIs.py
